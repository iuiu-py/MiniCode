# Claude Code — 泄露源码（2026-03-31）

> **2026 年 3 月 31 日，Anthropic 的 Claude Code CLI 完整源代码通过其 npm 注册表中暴露的 `.map` 文件被泄露。**

---

## 泄露经过

[Chaofan Shou（@Fried_rice）](https://x.com/Fried_rice) 发现泄露并公开披露：

> **「Claude Code 的源代码通过 npm 注册表里的 map 文件泄露了！」**
>
> — [@Fried_rice，2026 年 3 月 31 日](https://x.com/Fried_rice/status/2038894956459290963)

已发布的 npm 包中的 source map 文件指向了完整、未混淆的 TypeScript 源码，该源码曾可作为 zip 从 Anthropic 的 R2 存储桶下载。

---

## 概览

Claude Code 是 Anthropic 官方的 CLI 工具，让你在终端中直接与 Claude 交互，完成软件工程任务——编辑文件、运行命令、搜索代码库、管理 Git 工作流等。

本仓库收录的是泄露的 `src/` 目录。

- **泄露日期**：2026-03-31
- **语言**：TypeScript
- **运行时**：Bun
- **终端 UI**：React + [Ink](https://github.com/vadimdemedes/ink)（面向 CLI 的 React）
- **规模**：约 1,900 个文件，51 万余行代码

---

## 目录结构

```
src/
├── main.tsx                 # 入口（基于 Commander.js 的 CLI 解析）
├── commands.ts              # 命令注册表
├── tools.ts                 # 工具注册表
├── Tool.ts                  # 工具类型定义
├── QueryEngine.ts           # LLM 查询引擎（核心 Anthropic API 调用）
├── context.ts               # 系统/用户上下文收集
├── cost-tracker.ts          # Token 费用追踪
│
├── commands/                # 斜杠命令实现（约 50 个）
├── tools/                   # Agent 工具实现（约 40 个）
├── components/              # Ink UI 组件（约 140 个）
├── hooks/                   # React hooks
├── services/                # 外部服务集成
├── screens/                 # 全屏界面（Doctor、REPL、Resume 等）
├── types/                   # TypeScript 类型定义
├── utils/                   # 工具函数
│
├── bridge/                  # IDE 集成桥接（VS Code、JetBrains）
├── coordinator/             # 多 Agent 协调器
├── plugins/                 # 插件系统
├── skills/                  # Skill 系统
├── keybindings/             # 快捷键配置
├── vim/                     # Vim 模式
├── voice/                   # 语音输入
├── remote/                  # 远程会话
├── server/                  # 服务器模式
├── memdir/                  # 记忆目录（持久化记忆）
├── tasks/                   # 任务管理
├── state/                   # 状态管理
├── migrations/              # 配置迁移
├── schemas/                 # 配置模式（Zod）
├── entrypoints/             # 初始化逻辑
├── ink/                     # Ink 渲染器封装
├── buddy/                   # 陪伴精灵（彩蛋）
├── native-ts/               # 原生 TypeScript 工具
├── outputStyles/            # 输出样式
├── query/                   # 查询流水线
└── upstreamproxy/           # 代理配置
```

---

## 核心架构

### 1. 工具系统（`src/tools/`）

Claude Code 可调用的每个工具都是独立模块，各自定义输入 schema、权限模型与执行逻辑。

| 工具 | 说明 |
|---|---|
| `BashTool` | 执行 Shell 命令 |
| `FileReadTool` | 读取文件（图片、PDF、笔记本等） |
| `FileWriteTool` | 创建/覆盖文件 |
| `FileEditTool` | 局部修改文件（字符串替换） |
| `GlobTool` | 按模式匹配搜索文件 |
| `GrepTool` | 基于 ripgrep 的内容搜索 |
| `WebFetchTool` | 抓取 URL 内容 |
| `WebSearchTool` | 网页搜索 |
| `AgentTool` | 派生子 Agent |
| `SkillTool` | 执行 Skill |
| `MCPTool` | 调用 MCP 服务器工具 |
| `LSPTool` | 语言服务器协议（LSP）集成 |
| `NotebookEditTool` | 编辑 Jupyter 笔记本 |
| `TaskCreateTool` / `TaskUpdateTool` | 创建与管理任务 |
| `SendMessageTool` | Agent 间消息 |
| `TeamCreateTool` / `TeamDeleteTool` | 团队 Agent 管理 |
| `EnterPlanModeTool` / `ExitPlanModeTool` | 计划模式开关 |
| `EnterWorktreeTool` / `ExitWorktreeTool` | Git worktree 隔离 |
| `ToolSearchTool` | 延迟工具发现 |
| `CronCreateTool` | 创建定时触发器 |
| `RemoteTriggerTool` | 远程触发 |
| `SleepTool` | 主动模式下的等待 |
| `SyntheticOutputTool` | 结构化输出生成 |

### 2. 命令系统（`src/commands/`）

用户通过 `/` 前缀调用的斜杠命令。

| 命令 | 说明 |
|---|---|
| `/commit` | 创建 Git 提交 |
| `/review` | 代码审查 |
| `/compact` | 压缩上下文 |
| `/mcp` | MCP 服务器管理 |
| `/config` | 设置管理 |
| `/doctor` | 环境诊断 |
| `/login` / `/logout` | 身份认证 |
| `/memory` | 持久化记忆管理 |
| `/skills` | Skill 管理 |
| `/tasks` | 任务管理 |
| `/vim` | Vim 模式开关 |
| `/diff` | 查看变更 |
| `/cost` | 查看使用费用 |
| `/theme` | 切换主题 |
| `/context` | 上下文可视化 |
| `/pr_comments` | 查看 PR 评论 |
| `/resume` | 恢复上次会话 |
| `/share` | 分享会话 |
| `/desktop` | 交给桌面应用 |
| `/mobile` | 交给移动应用 |

### 3. 服务层（`src/services/`）

| 服务 | 说明 |
|---|---|
| `api/` | Anthropic API 客户端、文件 API、引导启动 |
| `mcp/` | 模型上下文协议（MCP）服务器连接与管理 |
| `oauth/` | OAuth 2.0 认证流程 |
| `lsp/` | 语言服务器协议管理器 |
| `analytics/` | 基于 GrowthBook 的特性开关与分析 |
| `plugins/` | 插件加载器 |
| `compact/` | 对话上下文压缩 |
| `policyLimits/` | 组织策略限制 |
| `remoteManagedSettings/` | 远程托管设置 |
| `extractMemories/` | 自动提取记忆 |
| `tokenEstimation.ts` | Token 数量估算 |
| `teamMemorySync/` | 团队记忆同步 |

### 4. 桥接系统（`src/bridge/`）

连接 IDE 扩展（VS Code、JetBrains）与 Claude Code CLI 的双向通信层。

- `bridgeMain.ts` — 桥接主循环
- `bridgeMessaging.ts` — 消息协议
- `bridgePermissionCallbacks.ts` — 权限回调
- `replBridge.ts` — REPL 会话桥接
- `jwtUtils.ts` — 基于 JWT 的认证
- `sessionRunner.ts` — 会话执行管理

### 5. 权限系统（`src/hooks/toolPermission/`）

在每次工具调用时检查权限：要么提示用户批准/拒绝，要么根据配置的权限模式（`default`、`plan`、`bypassPermissions`、`auto` 等）自动处理。

### 6. 特性开关

通过 Bun 的 `bun:bundle` 特性开关做死代码剔除：

```typescript
import { feature } from 'bun:bundle'

// 未启用的代码在构建时会被完全剥离
const voiceCommand = feature('VOICE_MODE')
  ? require('./commands/voice/index.js').default
  : null
```

常见开关：`PROACTIVE`、`KAIROS`、`BRIDGE_MODE`、`DAEMON`、`VOICE_MODE`、`AGENT_TRIGGERS`、`MONITOR_TOOL`

---

## 关键文件说明

### `QueryEngine.ts`（约 4.6 万行）

LLM API 调用的核心引擎：处理流式响应、工具调用循环、思考模式、重试逻辑与 Token 计数。

### `Tool.ts`（约 2.9 万行）

定义所有工具的基础类型与接口——输入 schema、权限模型与进度状态类型。

### `commands.ts`（约 2.5 万行）

管理全部斜杠命令的注册与执行；通过条件导入按环境加载不同命令集。

### `main.tsx`

基于 Commander.js 的 CLI 解析 + React/Ink 渲染初始化。启动时并行预取 MDM 设置、钥匙串与 GrowthBook，以加快冷启动。

---

## 技术栈

| 类别 | 技术 |
|---|---|
| 运行时 | [Bun](https://bun.sh) |
| 语言 | TypeScript（严格模式） |
| 终端 UI | [React](https://react.dev) + [Ink](https://github.com/vadimdemedes/ink) |
| CLI 解析 | [Commander.js](https://github.com/tj/commander.js)（extra-typings） |
| Schema 校验 | [Zod v4](https://zod.dev) |
| 代码搜索 | [ripgrep](https://github.com/BurntSushi/ripgrep)（经 GrepTool） |
| 协议 | [MCP SDK](https://modelcontextprotocol.io)、LSP |
| API | [Anthropic SDK](https://docs.anthropic.com) |
| 遥测 | OpenTelemetry + gRPC |
| 特性开关 | GrowthBook |
| 认证 | OAuth 2.0、JWT、macOS 钥匙串 |

---

## 值得注意的设计模式

### 并行预取

在重量级模块求值之前，并行预取 MDM 设置、钥匙串读取与 API 预连接，以优化启动时间。

```typescript
// main.tsx — 在其他 import 之前作为副作用触发
startMdmRawRead()
startKeychainPrefetch()
```

### 延迟加载

OpenTelemetry（约 400KB）、gRPC（约 700KB）等重模块通过动态 `import()` 推迟到真正需要时再加载。

### Agent 集群

通过 `AgentTool` 派生子 Agent，`coordinator/` 负责多 Agent 编排；`TeamCreateTool` 支持团队级并行工作。

### Skill 系统

在 `skills/` 中定义可复用工作流，经 `SkillTool` 执行；用户可添加自定义 Skill。

### 插件架构

内置与第三方插件通过 `plugins/` 子系统加载。

---

## 免责声明

本仓库归档的源代码于 **2026-03-31** 自 Anthropic 的 npm 注册表相关事件中流出。全部原始源码归 [Anthropic](https://www.anthropic.com) 所有。
